MYSQL_PASSWORD = "nem14@NemesisDataBase"
DB_NAME = "Online_Exam_System"
